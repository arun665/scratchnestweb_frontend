
function Pearsonl(){
    return(<>
    </>);
}


export default Pearsonl;