
import './sector.scss';
import img1 from './img1.png';
import img2 from './img2.png';
import img3 from './img3.png';

function Sector(){
    return(
        <div id="sector" >
            <div className="container-fluid">
<div className="row">
    <div id="heading" className="col-md-12 col-sm-12 col-12">
        <h1> Our Major Sectors</h1>
    </div>
    <div className="col-md-4 col-sm-4 col-12">
           
           <div id="box" data-aos="fade-left">
               <img src={img1} />

               <h2> Heading </h2>
               <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fkusce mattis tortor viverra dictum nunc consequat, molestie leo. Tortor eleifend.</p>
           </div>
        

    </div>

    <div className="col-md-4 col-sm-4 col-12">
           
           <div id="box" data-aos="zoom-out">
               <img src={img2} />

               <h2> Heading </h2>
               <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fkusce mattis tortor viverra dictum nunc consequat, molestie leo. Tortor eleifend.</p>
           </div>
        

    </div>

    <div className="col-md-4 col-sm-4 col-12">
           
           <div id="box" data-aos="fade-right">
               <img src={img3} />

               <h2> Heading </h2>
               <p> Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fkusce mattis tortor viverra dictum nunc consequat, molestie leo. Tortor eleifend.</p>
           </div>
        

    </div>
</div>
</div>


        </div>
    );
}


export default Sector;