import TopHeader from '../top_header/index';
import './About.scss';
import Footer from '../Footer/footer2';
import img from './img.png';
import {useEffect} from 'react';

import Sector from './sectors/sector';
import Founder from './founder/founder';
import Partner from './Partner/partner';
function About(){

    useEffect(() => {
        window.scrollTo(0, 0);
        document.title = "About Us";
        
      }, [])

    return (
    <>
    <TopHeader/>
    <div id="about">
<div className="container-fluid" id="outdiv1">

<div className="row" id="div1">

<div className="col-sm-6 col-md-6 col-12">

<div id="heading">
    <h1> Our Story </h1>
    <p>        Some aspiring IITians belonging to different fields, under the
                esteemed guidance of their professor, build this revolutionary
                forum where they design everything from “scratch” and come up
                with technologies never made in India before. ScratchNest is an
                Indian company incubated in Technology Business Incubator IIT
                Ropar. We believe in providing our users with the best possible
                service and inspiration to make the “first of its kind”. </p>
</div>
</div>


<div className="col-sm-6 col-md-6 col-12">

<img src={img} id="img"/>

</div>


<div className="col-sm-4 col-md-4 col-12">

<div id="heading2">
    <h1> Our Vision</h1>
    <p>        
        
        
              ScratchNest pioneers in delivering customized experiences of
                    the next-gen technologies and bringing innovation to
                    everything you use. We develop RFID, NFC, NBIoT, Bluetooth
                    devices and Dataloggers crafted totally from scratch,
                    delivering you with the never-before experience. </p>
</div>
</div>

<div className="col-sm-4 col-md-4 col-12">

<div id="heading2">
    <h1> What we do? </h1>
    <p>                Our team engineers the best in devices to suit your needs
                    and transform physical systems into intelligent workers.
                    Come, see how fun systems can be when equipped with
                    ScratchNest. </p>
</div>
</div>


<div className="col-sm-4 col-md-4 col-12">

<div id="heading2">
    <h1> Why choose us? </h1>
    <p>            ...to reach that pinnacle where we reside in the roots of
                service providers, where every IoT brand of the world has
                ‘ScratchNest’ printed somewhere in its depths, and where
                ScratchNest is the first trusted name in mind whenever it comes
                to IoT. </p>
</div>
</div>







</div>



</div>

<Sector/>

<Founder/>
<Partner/>
    </div>
    <Footer/>
    </>)
}



export default About;