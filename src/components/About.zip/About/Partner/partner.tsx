
import './partner.scss';

function partner(){
    return(<div id="founder">

<div className="container-fluid" >
<div className="row">
    <div id="heading" className="col-md-12 col-sm-12 col-12">
        <h1>Our Partners {'&'} Customers</h1>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box" data-aos="fade-down">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>
    <div className="col-md-4 col-sm-4 col-6">
           <div id="box">
               <img src="https://res.cloudinary.com/dpysmqax5/image/upload/v1616922167/akshit_wdadcm.png" />

           </div>
    </div>



</div>
</div>






    </div> 

    );
}


export default partner;