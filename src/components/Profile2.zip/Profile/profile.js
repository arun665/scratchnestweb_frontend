import Topheader from '../top_header/index';
import Footer from '../Footer/footer2';
import { Profiler, useState } from 'react';
import Man from './man.jpg';
import './profile.scss';
import axios from 'axios';
import React from 'react';
import Beacon from './beacon2.png';
class Profile extends React.Component {

    state = {
        loader:true,
        display:false,
        display2:false,
            order_id: new URLSearchParams(this.props.location.search).get("order_id"),
            billing_name: new URLSearchParams(this.props.location.search).get("billing_name"),
            billing_address: new URLSearchParams(this.props.location.search).get("billing_address"),
            billing_city: new URLSearchParams(this.props.location.search).get("billing_city"),
            billing_state:new URLSearchParams(this.props.location.search).get("billing_state"),
            billing_zip:new URLSearchParams(this.props.location.search).get("billing_zip"),
            amount:new URLSearchParams(this.props.location.search).get("amount"),
            order_status:new URLSearchParams(this.props.location.search).get("order_status"),
            prods:[]
          };
    componentDidMount = () => {
        //console.log(new URLSearchParams(this.props.location.search).get("amount"));
        this.getCart();
      }
    
      getCart = () => {
        axios({
            url: 'https://api.scratchnest.com/cart',
            method: 'GET',
            withCredentials:true
            //data: payload
          })
          .then((res) => { 
            console.log(res.data.user.cart.items);
            const prods = res.data.user.cart.items;
            this.setState({prods:prods})
    
          }).catch((err) => {
            console.log(err);
            
          });
      }
    //function Confirmation(){
      cartprod = (prods) => {
        if (prods.length) {
    return prods.map((post, i) => (
        /* thses are the real igtems from database */
    
          <div className="row" id="items" key={i}>
            <div className="col-sm-4 col-md-4 col-5">
              <img src={Beacon} />
            </div>
            <div className="col-sm-8 col-md-8 col-7">
              <h1> {post.product_title} </h1>
              <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
    
              {/* desktop listing of products */}
              <div id="desktop">
                <div className="form-group- form-inline" >
                  <label id="itemquantity">Qty:</label>
                 
     {/* here is the new button gruoup to increment ans decrement the items quantity*/}
     
     <select className="form-control" >
        <option>{post.qty} </option>
    
      </select>
                    
    {/*------------------------------------------------------------*/}
                </div>
                <table>
                  <tr>
                    <td>
                      <h2>Price: <span>( <del>₹ {post.price + (post.price / 10)} </del>) </span>  <span id="span2">₹ {post.price} </span>  </h2>
                    </td>
                  </tr>
                </table>
              </div>
            </div>
            
            <div className="col-sm-0 col-md-0 col-12">
    <div id="phone">
    <table>
        <tr>
            <td>
        <div className="form-group- form-inline" >
      <label id="itemquantity">Qty:</label>
      <select className="form-control" >
        <option>{post.qty}</option>
    
      </select>
    </div>
    </td>
    <td></td>
    </tr>
        <tr>
            <td colSpan={2}>
    <h2>Price: <span>( <del>₹ {post.price + (post.price / 10)}</del>) </span>  <span id="span2">₹  {post.price}</span>  </h2>
    </td>
    
    </tr>
    </table>
    </div>
    </div>
          </div>  ))}}
        
    


    
   render() {
    return(
        <>
        <Topheader/>
        <div id="profile">

<div className="container-fluid out">
<div className="row">
<div className="col-sm-4 col-md-4 col-12 " >

<div id="left">
    {/* -------------------------------------------------Image will be added here-------------------------------*/}
    <img src={Man} className="rounded-circle"  id="image" />
    <br></br>    <br></br>
    

<div id="data">
<h1> First Name </h1>

<h2><i class="fa fa-map-marker"></i>  State , Country </h2>

<hr></hr>
<h3> <i class="fa fa-phone"></i>1234567889 </h3>

<h4><i class="fa fa-envelope"></i>  abc@gmail.com </h4>

<hr></hr>
<h5> My Address:</h5>
<h5> 601 , random address </h5>
<h5>abc city </h5>
<h5> PinCode-16005</h5>
<br></br>
<br></br>
<button className="btn btn-primary">Edit Profile Details</button>
</div>
</div>
</div>
<div className="col-sm-8 col-md-8 col-12 right">

<div id="list">

<div id="heading">
    <h1> Your Profile </h1>
</div>
<br></br>

<div id="heading">
    <p> Your Orders (4) </p>
</div>
{/* sample code for item , later we will add an array here  ------------------------------------------------------------------*/}

<div className="row" id="items">

<div className="col-sm-4 col-md-4 col-5">

<img src={Beacon} />
</div>


<div className="col-sm-8 col-md-8 col-7">
    <h1> Tracking Beacon SN-TB101 </h1>
    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
    <div id="desktop">
    <div className="form-group- form-inline" >
  <label id="itemquantity">Qty:</label>
  <select className="form-control" >
    <option>1</option>
 
  </select>
</div>
<table>
    <tr>
        <td>
<h2>Price: <span>( <del>₹ 2620 </del>) </span>  <span id="span2">sdfsdf</span>  </h2>
</td>
<td>

</td>
</tr>
</table>
</div>
</div>

<div className="col-sm-0 col-md-0 col-12">
<div id="phone">
<table>
    <tr>
        <td>
    <div className="form-group- form-inline" >
  <label id="itemquantity">Qty:</label>
  <select className="form-control" >
    <option>1</option>

  </select>
</div>
</td>
<td>

</td>
</tr>
    <tr>
        <td colSpan={2}>
<h2>Price: <span>( <del>₹ 2620 </del>) </span>  <span id="span2">₹ 2629</span>  </h2>
</td>

</tr>
</table>
</div>
</div>

</div>
<br></br>
<button className="btn btn-outline-primary" onClick={()=>this.setState({display:true})}>Show More</button>


{this.cartprod(this.state.prods)}
{/* saple item fo product end herer ------------------------------------------------------------------*/}


</div>




{/* This is the section for previous orders ------------------------------------------------------------------*/}

<div id="list">


<br></br>

<div id="heading">
    <p> Previous Orders (4) </p>
</div>
{/* sample code for item , later we will add an array here  ------------------------------------------------------------------*/}

<div className="row" id="items">

<div className="col-sm-4 col-md-4 col-5">

<img src={Beacon} />
</div>


<div className="col-sm-8 col-md-8 col-7">
    <h1> Tracking Beacon SN-TB101 </h1>
    <p> Lorem Ipsum is simply dummy text of the printing and typesetting industry.</p>
    <div id="desktop">
    <div className="form-group- form-inline" >
  <label id="itemquantity">Qty:</label>
  <select className="form-control" >
    <option>1</option>
 
  </select>
</div>
<table>
    <tr>
        <td>
<h2>Price: <span>( <del>₹ 2620 </del>) </span>  <span id="span2">sdfsdf</span>  </h2>
</td>
<td>

</td>
</tr>
</table>
</div>
</div>

<div className="col-sm-0 col-md-0 col-12">
<div id="phone">
<table>
    <tr>
        <td>
    <div className="form-group- form-inline" >
  <label id="itemquantity">Qty:</label>
  <select className="form-control" >
    <option>1</option>

  </select>
</div>
</td>
<td>

</td>
</tr>
    <tr>
        <td colSpan={2}>
<h2>Price: <span>( <del>₹ 2620 </del>) </span>  <span id="span2">₹ 2629</span>  </h2>
</td>

</tr>
</table>
</div>
</div>

</div>
<br></br>
<button className="btn btn-outline-primary" onClick={ ()=>this.setState({display2:!this.state.display2})}>Show More</button>

{/* saple item fo product end herer ------------------------------------------------------------------*/}


</div>










</div>

</div>
</div>

        </div>


<Footer/>
</>
    );
   }
}


export default Profile;